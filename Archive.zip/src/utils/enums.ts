export enum SwipeType {
  LIKE = 'LIKE',
  PASS = 'PASS',
}
