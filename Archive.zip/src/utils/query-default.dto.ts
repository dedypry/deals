export class QueryDtoDefault {
  page: number;
  limit: number;
  search: string;
}
