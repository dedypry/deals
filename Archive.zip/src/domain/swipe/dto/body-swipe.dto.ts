import { SwipeType } from 'src/utils/enums';

export class BodySwipeDto {
  target_user_id: number;
  type: SwipeType;
}
