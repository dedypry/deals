export class InsertPremiumDto {
  premium_id: number;
}
